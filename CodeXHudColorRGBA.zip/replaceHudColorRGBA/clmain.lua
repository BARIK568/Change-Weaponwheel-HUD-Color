Citizen.CreateThread(function()
    ReplaceHudColourWithRgba(
        116, -- old Color
        240, -- R
        153, -- G
        153, -- B
        255 -- A
    )
end)