fx_version 'bodacious'
game 'gta5'

author Barik

description build by CODE X STORE

client_scripts {
    'clmain.lua',
}